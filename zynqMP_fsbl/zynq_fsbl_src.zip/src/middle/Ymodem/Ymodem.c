/**************************************************************************************************
 * INCLUDES
 **************************************************************************************************/
#include "Ymodem.h"
#include <string.h>
#include "userFirmwareUpdate.h"
#include "userTask.h"
/*********************************************************************
 * CONSTANTS
 */
/*********************************************************************
 * GLOBAL VARIABLES
 */
static uint8 ym_rx_status = YMODEM_RX_IDLE;
uint32_t ym_rx_idle_tick = 0;
static uint8 ym_tx_status = YMODEM_TX_IDLE;
static size_t pac_size;
static size_t seek;
static size_t ym_tx_fil_sz;
static char ym_tx_pbuf[PACKET_OVERHEAD + PACKET_1K_SIZE];
static uint8 ym_cyc; // ����ʱ����ת����

T_YmodemInfo gYmodemCtrl;
/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 *********************************************************************/

/*********************************************************************
 * TYPE_DEFS
 */

/*********************************************************************
 * FUNCTIONS
 *********************************************************************/

extern u8 ReadBuffer[];
void YmodemInit(void)
{
    memset((char*)&gYmodemCtrl, 0, sizeof(gYmodemCtrl));
    prx_file_data = ReadBuffer;

}
unsigned short crc16(const unsigned char *buf, unsigned long count)
{
  unsigned short crc = 0;
  int i;

  while (count--)
  {
    crc = crc ^ *buf++ << 8;

    for (i = 0; i < 8; i++)
    {
      if (crc & 0x8000)
      {
        crc = crc << 1 ^ 0x1021;
      }
      else
      {
        crc = crc << 1;
      }
    }
  }
  return crc;
}

static const char *u32_to_str(unsigned int val)
{
  /* Maximum number of decimal digits in u32 is 10 */
  static char num_str[11];
  int pos = 10;
  num_str[10] = 0;

  if (val == 0)
  {
    /* If already zero then just return zero */
    return "0";
  }

  while ((val != 0) && (pos > 0))
  {
    num_str[--pos] = (val % 10) + '0';
    val /= 10;
  }

  return &num_str[pos];
}

static unsigned long str_to_u32(char *str)
{
  const char *s = str;
  unsigned long acc;
  int c;

  /* strip leading spaces if any */
  do
  {
    c = *s++;
  } while (c == ' ');

  for (acc = 0; (c >= '0') && (c <= '9'); c = *s++)
  {
    c -= '0';
    acc *= 10;
    acc += c;
  }
  return acc;
}
// Return packet type
uint8 ymodem_rx_pac_check(char *buf, size_t sz)
{
  char ch;
  ch = buf[0];
  if (sz < 128) // �Ǹ�ָ���
  {
    if (ch == EOT || ch == ACK || ch == NAK || ch == CAN || ch == CNC)
    {
      int i = 1;
      while (i < sz && buf[i++] == ch)
        ;          // �жϰ������������Ƿ�һ��
      if (sz == i) // ��ȫ��һ���Ļ�������Ϊ���������Ч
        return ch;
      else
        return 0xff;
    }
    else
      return 0xff; // �����ָ����
  }
  else
  {
    if (ch == SOH || ch == STX)
    {
      u16 crc1 = crc16((u8 *)(buf + PACKET_HEADER), sz - PACKET_OVERHEAD);
      uint8_t crcH,crcL;
      crcH = buf[sz - 2];
      crcL = buf[sz - 1];
    //   u16 crc2 =  (((uint8_t)buf[sz - 2])<<16) | ((uint8_t)buf[sz - 1]);
      u16 crc2 =  crcH<<8 | crcL;
      if (crc1 == crc2 && 0xff == (u8)buf[1] + (u8)buf[2])
        return ch;
      else
        return 0xff;
    }
    else
      return 0xff;
  }
}
//**********************************************************************RX part
uint8 ymodem_rx_pac_if_empty(char *buf, size_t sz)
{
  size_t offset = 0;
  while (buf[offset] == 0x00 && ++offset < sz)
    ;
  if (offset == sz)
    return 1; // TRUE
  else
    return 0; // FALSE
}
uint8 ymodem_rx_prepare(char *buf, size_t sz)
{
  uint8 ans = YMODEM_OK;
  char *fil_nm;
  uint8 fil_nm_len;
  size_t fil_sz;
  fil_nm = buf;
  fil_nm_len = strlen(fil_nm);
  fil_sz = (size_t)str_to_u32(buf + fil_nm_len + 1);
  ans = ymodem_rx_header(fil_nm, fil_sz);
  return ans;
}
/*********************************************************************
 * @fn      ymodem_tx_put : Ymodem����ʱ���߼���ת���ú���
 * @param   buf : ���ݻ����� buf : ���ݴ�С
 */
void ymodem_rx_put(char *buf, size_t rx_sz)
{
  if (0 == rx_sz) // ��ʱ���Ӷ��õ��ĳ���Ϊ0�����Է��͡�C����������
  {
    if(ym_rx_status == YMODEM_RX_IDLE)
        __putchar('C');
    return;
  }

  switch (ym_rx_status)
  {
  case YMODEM_RX_IDLE:
    switch (ymodem_rx_pac_check(buf, rx_sz)) // ��鵱ǰ���Ƿ�Ϸ�,�����ذ�������
    {
    case SOH:
    case STX:
      pac_size = (u8)(buf[0]) == SOH ? PACKET_SIZE : PACKET_1K_SIZE;
      if (1 == ymodem_rx_pac_if_empty(buf + PACKET_HEADER, pac_size))// �ж��Ƿ��ǿհ�
      {
        __putchar(ACK);
        ym_rx_status = YMODEM_RX_EXIT;
        goto exit; // �����ڱ�ѭ��������ɵĲ�����������Ҫ�õ� goto ���
      }
      else // ������ǿհ�������Ϊ�ǵ�һ�����������ļ������ļ���С��
      {
        if (/*pac_size == 128 &&*/ YMODEM_OK == ymodem_rx_prepare(buf + PACKET_HEADER, pac_size))
        {
          __putchar(ACK);
          seek = 0; // ��ʼ�����������ڽ������ļ�
          __putchar('C');
        //   gYmodemCtrl.newdata = 1;
          gYmodemCtrl.u8packteNum = 0;
          ym_rx_status = YMODEM_RX_ACK;
        }
        else
          goto err; // ��IDLE�н��յ�һ��1024�����ݰ�����϶���״̬������
      }
      break;
    case EOT:
      ym_rx_status = YMODEM_RX_EXIT;
      goto exit; // �����ڱ�ѭ��������ɵĲ�����������Ҫ�õ� goto ���
      break;
    default:
      //     __putchar( NAK );      //��������״̬��������
      // goto err; // �����ʱ��Ϊ�������󣬾��˳�
      break;
    }
    break;
  case YMODEM_RX_ACK:                        // 1�������ļ�����״̬��
    switch (ymodem_rx_pac_check(buf, rx_sz)) // ��鵱ǰ���Ƿ�Ϸ�,�����ذ�������
    {
    case SOH:
    case STX:
        if(gYmodemCtrl.u8packteNum == (uint8_t)buf[1])
        {
            Ym_printf("packet repeat!(%d)!\r\n",gYmodemCtrl.u8packteNum);
            //* already receive the packet
            __putchar(ACK);
            break;
        }
        //* refresh packet num
        gYmodemCtrl.u8packteNum = (uint8_t)buf[1];
        __putchar(ACK);
        pac_size = (u8)(buf[0]) == SOH ? PACKET_SIZE : PACKET_1K_SIZE;
        ymodem_rx_pac_get(buf + PACKET_HEADER, seek, pac_size); // �����յİ�����
        seek += pac_size;
        // __putchar('C');
      break;
      // ָ���
    case EOT:
      __putchar(NAK);
      ym_rx_status = YMODEM_RX_EOT;
      break;
    case CAN:
      ym_rx_status = YMODEM_RX_ERR;
      goto err;
      break;
    default:
      __putchar(NAK); // ��������״̬��������
      //          goto err;           //�����ʱ��Ϊ�������󣬾��ط�
      break;
    }
    break;
  case YMODEM_RX_EOT: // �����ﱣ���ļ�
  {
    switch (ymodem_rx_pac_check(buf, rx_sz)) // ��鵱ǰ���Ƿ�Ϸ�,�����ذ�������
    {
      // ָ���
    case EOT:
      __putchar(ACK);
      ymodem_rx_finish(YMODEM_OK); // ȷ�Ϸ�����ϣ������ļ�
      __putchar('C');
      ym_rx_status = YMODEM_RX_SOTNULL;
      break;
    case SOH:
        __putchar(ACK);
        ym_rx_status = YMODEM_RX_IDLE;
        break;
    default:
      goto err;
      break;
    }
  }
  break;
  case YMODEM_RX_SOTNULL: //wait sot null package
    switch (ymodem_rx_pac_check(buf, rx_sz)) // ��鵱ǰ���Ƿ�Ϸ�,�����ذ�������
    {
    case SOH:
        __putchar(ACK);
        ym_rx_status = YMODEM_RX_IDLE;
        break;
    default:
      goto err;
      break;
    }
    ym_rx_status = YMODEM_RX_IDLE;
    break;
  err:
  case YMODEM_RX_ERR: // ��������������ļ�,��ֹ����
    __putchar(CAN);
    ymodem_rx_finish(YMODEM_ERR);
    // break;                    //û��break�������湫�ô���
  exit:
  case YMODEM_RX_EXIT: // ���������ʰ�ã�Ȼ���˳�
    ym_rx_status = YMODEM_RX_IDLE;
    // No more calls to ymodem_rx_put()
    return;
  default:
    break;
  }
}
//**********************************************************************TX part
uint8 ymodem_tx_make_pac_data(char *pbuf, size_t pac_sz)
{
  uint8 ans = YMODEM_ERR;
  uint16 crc;

  pbuf[0] = pac_sz == 128 ? SOH : STX;
  pbuf[1] = ym_cyc;
  pbuf[2] = ~ym_cyc;
  crc = crc16((unsigned char const *)pbuf + PACKET_HEADER, pac_sz);
  pbuf[PACKET_HEADER + pac_sz] = (u8)(crc / 256);
  pbuf[PACKET_HEADER + pac_sz + 1] = (u8)(crc & 0x00ff);
  ym_cyc++;
  ans = YMODEM_OK;
  return ans;
}
uint8 ymodem_tx_make_pac_header(char *pbuf, char *fil_nm, size_t fil_sz)
{
  uint8 ans = YMODEM_ERR;
  uint8 nm_len;
  memset(pbuf + PACKET_HEADER, 0, 128);
  if (fil_nm)
  {
    nm_len = strlen(fil_nm);
    strcpy(pbuf + PACKET_HEADER, fil_nm);
    strcpy(pbuf + PACKET_HEADER + nm_len + 1, u32_to_str(fil_sz));
  }
  ym_cyc = 0x00;
  ymodem_tx_make_pac_data(pbuf, 128);
  ans = YMODEM_OK;
  return ans;
}
/*********************************************************************
 * @fn      ymodem_tx_put : Ymodem sender logic
 * @param   buf : data buffer buf : data size
 */
void ymodem_tx_put(char *buf, size_t rx_sz)
{
  char *fil_nm = NULL;
  size_t fil_sz = 0;
  switch (ym_tx_status)
  {
  case YMODEM_TX_IDLE:
    switch (ymodem_rx_pac_check(buf, rx_sz))
    {
    case CNC:
    {
      if (YMODEM_OK == ymodem_tx_header(&fil_nm, &fil_sz))
      {
        ym_tx_fil_sz = fil_sz;
        ymodem_tx_make_pac_header(ym_tx_pbuf, fil_nm, fil_sz);
        __putbuf(ym_tx_pbuf, PACKET_OVERHEAD + PACKET_SIZE);
        ym_tx_status = YMODEM_TX_IDLE_ACK;
      }
      else
      {
        ymodem_tx_make_pac_header(ym_tx_pbuf, NULL, 0);
        __putbuf(ym_tx_pbuf, PACKET_OVERHEAD + PACKET_SIZE);
      }
    }
    break;
    case CAN:
      ym_tx_status = YMODEM_TX_ERR;
      goto err_tx;
      break;
    default:
      goto err_tx;
      break;
    }
    break;
  case YMODEM_TX_IDLE_ACK:
  {
    switch (ymodem_rx_pac_check(buf, rx_sz))
    {
    case ACK:
      ym_tx_status = YMODEM_TX_DATA;
      break;
    case NAK:
      ym_tx_status = YMODEM_TX_IDLE;
      break;
    default:
      break;
    }
  }
  break;
  dt_tx:
  case YMODEM_TX_DATA:
    switch (ymodem_rx_pac_check(buf, rx_sz))
    {
    case CNC:
      if (YMODEM_OK == ymodem_tx_pac_get(ym_tx_pbuf + PACKET_HEADER, seek, PACKET_1K_SIZE))
      {
        if (YMODEM_OK == ymodem_tx_make_pac_data(ym_tx_pbuf, PACKET_1K_SIZE))
        {
          __putbuf(ym_tx_pbuf, PACKET_OVERHEAD + PACKET_1K_SIZE);
          ym_tx_status = YMODEM_TX_DATA_ACK;
        }
        else
        {
          ym_tx_status = YMODEM_TX_ERR;
          goto err_tx;
        }
      }
      break;
    case CAN:
      ym_tx_status = YMODEM_TX_ERR;
      goto err_tx;
      break;
    default:
      break;
    }
    break;
  case YMODEM_TX_DATA_ACK:
  {
    switch (ymodem_rx_pac_check(buf, rx_sz))
    {
    case ACK:
      seek += PACKET_1K_SIZE;
      if (seek < ym_tx_fil_sz)
        ym_tx_status = YMODEM_TX_DATA;
      else
      {
        ym_tx_status = YMODEM_TX_EOT;
        __putchar(EOT);
      }
      break;
    case CNC:
      seek += PACKET_1K_SIZE;
      if (seek < ym_tx_fil_sz)
      {
        ym_tx_status = YMODEM_TX_DATA;
        goto dt_tx;
      }
      else
      {
        ym_tx_status = YMODEM_TX_EOT;
        __putchar(EOT);
      }
      break;
    default:
      break;
    }
  }
  break;
  case YMODEM_TX_EOT:
  {
    switch (ymodem_rx_pac_check(buf, rx_sz))
    {
    case NAK:
      __putchar(EOT);
      break;
    case ACK:
      __putchar(ACK);
      ymodem_tx_finish(YMODEM_OK);
      ym_tx_status = YMODEM_TX_IDLE;
      break;
    default:
      break;
    }
  }
  break;
  err_tx:
  case YMODEM_TX_ERR:
    __putchar(CAN);
    ymodem_tx_finish(YMODEM_ERR);
  case YMODEM_TX_EXIT:
    ym_tx_status = YMODEM_TX_IDLE;
    return;
  default:
    break;
  }
}

//* �ֽ�������


// ������ȫ�ֱ���
YmodemParseState ymodem_state = STATE_WAITING_SOH;
uint16_t data_len;
char rx_buffer[PACKET_OVERHEAD + PACKET_1K_SIZE];
size_t rx_byte_count = 0;
char current_packet_type;
//* Aseembe Packet of SOT STX
void Assemble_SOTSTX(char current_byte) {
    switch (ymodem_state) {
        case STATE_WAITING_SOH:
            if (current_byte == SOH || current_byte == STX)
            {
              current_packet_type = current_byte;
              rx_buffer[0] = current_byte;
              ymodem_state = STATE_WAITING_PKT_NUM;
              rx_byte_count = 1;
              data_len = (current_byte == SOH) ? PACKET_SIZE : PACKET_1K_SIZE;
            }
            else if (current_byte == EOT)
            {
              //* handle EOT after stx/sot
              rx_buffer[0] = current_byte;
              rx_byte_count = 1;
              ymodem_rx_put(rx_buffer, rx_byte_count);
            }
            break;

        case STATE_WAITING_PKT_NUM:
            rx_buffer[rx_byte_count++] = current_byte;
            ymodem_state = STATE_WAITING_PKT_NUM_INV;
            break;

        case STATE_WAITING_PKT_NUM_INV:
            rx_buffer[rx_byte_count++] = current_byte;
            uint8_t pkt_num = (uint8_t)rx_buffer[1];
            uint8_t pkt_num_inv = (uint8_t)rx_buffer[2];
            
            if ((pkt_num + pkt_num_inv) == 0xFF) {
                ymodem_state = STATE_WAITING_DATA;
            } else {
                ymodem_state = STATE_WAITING_SOH;
            }
            break;

        case STATE_WAITING_DATA:
            rx_buffer[rx_byte_count++] = current_byte;
            if (rx_byte_count - 3 >= data_len) {
                ymodem_state = STATE_WAITING_CRC_HI;
            }
            break;
        
        case STATE_WAITING_CRC_HI:
            rx_buffer[rx_byte_count++] = current_byte;
            ymodem_state = STATE_WAITING_CRC_LO;
            break;

        case STATE_WAITING_CRC_LO:
            rx_buffer[rx_byte_count++] = current_byte;
            if(ym_rx_status == YMODEM_RX_SOTNULL)
            {
              Ym_printf("recv sot null packet\r\n");
            }
            ymodem_rx_put(rx_buffer, rx_byte_count);
            ymodem_state = STATE_WAITING_SOH;
            break;

        default:
            ymodem_state = STATE_WAITING_SOH;
            break;
    }
}
//* other single data handle
void Prcoess_Other(char current_byte) {
      rx_buffer[0] = current_byte;
      rx_byte_count = 1;
      ymodem_rx_put(rx_buffer, rx_byte_count);
}

uint32_t tick_diff(uint32_t old);
uint32_t tick_get(void);
uint32_t tick_delay_ms(uint32_t ms);
//*

void YmodemProcess(char s8InputByte,char isValid)
{

  int ret = 0; 
  char ch;

  if(isValid == 0)
  {
    if(ym_rx_status == YMODEM_RX_IDLE)
    {
      if(tick_diff(ym_rx_idle_tick) > 100)
      {
      __putchar('C');
      ym_rx_idle_tick = tick_get();
      }
    }
    return;
  }
TAG_AGAIN:
  switch (ym_rx_status)
  {
  case YMODEM_RX_IDLE:
    Assemble_SOTSTX(s8InputByte);
    break;
  case YMODEM_RX_ACK:                        // 1�������ļ�����״̬��
    Assemble_SOTSTX(s8InputByte);
    break;
  case YMODEM_RX_SOTNULL:                        // 1�������ļ�����״̬��
    Assemble_SOTSTX(s8InputByte);
    break;
  case YMODEM_RX_EOT: // �����ﱣ���ļ�
  case YMODEM_RX_ERR: // ��������������ļ�,��ֹ����
  case YMODEM_RX_EXIT: // ���������ʰ�ã�Ȼ���˳�
    Prcoess_Other(s8InputByte);
    break;

  default:
    break;
  }

  if(YMODEM_RX_IDLE != ym_rx_status)
  {
      do
      {
        ret = PSUART_RX_BYTE_GET(s8InputByte);
      }while (!ret);
      goto TAG_AGAIN;
      
  }
}
