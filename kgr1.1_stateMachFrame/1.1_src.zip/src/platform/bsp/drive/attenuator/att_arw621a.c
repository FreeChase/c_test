/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    att_pe43711.c
  * @brief   This file provides code for the configuration
  *          of the SPI Attenuator PE43711 instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024, ZS Development Team.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  * Change Logs:
  * Date           Author       Notes
  * 2024-11-25     Andy      the first version
  * 2024-12-22     Andy      modify
  ******************************************************************************
  */
#include <att_arw621a.h>
#include <stdio.h>
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "dxdef.h"
#include "antijam_fpga.h"
#define PE43711_SPI_LEA		        (13)
#define PE43711_SPI_LEB		       	(0)
#define PE43711_SPI_SCLK 		    (14)
#define PE43711_SPI_SI		        (15)

/******************************************************************************/
/**
*
* This is the interrupt handler routine for the GPIO for this example.
*
* @param	CallbackRef is the Callback reference for the handler.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/


void att_dx_dly_us(unsigned int tmpVal)
{
	for(int i = 0; i< 1000*tmpVal ; i++);
}

//int IntrFlag;
//void pe43711_handler(void *CallbackRef)
//{
//
//	Xil_ExceptionDisable();
//	/* Clear the Interrupt */
//	Value[0]=antijam_fpga_read_reg(0xF7);
//	//Value[1]=antijam_fpga_read_reg(0xF8);
//	Value[1]=antijam_fpga_read_reg(0xF9);
//	Value[2]=antijam_fpga_read_reg(0xFa);
//	Value[3]=antijam_fpga_read_reg(0xFb);
//	Value[4]=antijam_fpga_read_reg(0xFc);
////	Value[2]=antijam_fpga_read_reg(0xFd);
////	Value[3]=antijam_fpga_read_reg(0xFe);
////	Value[4]=antijam_fpga_read_reg(0xFf);
//	IntrFlag = 1;
//    //Xil_ExceptionEnable();
//}

/*****************************************************************************************************
*	�� �� ��: static void pe43711_gpio_spi_begin(eAttPE43711ChipMux pe43711Mux)
*	����˵��: ģ��SPI����ǰ����Ӳ��SPI����ΪGPIO
*	��	  ��:
*			  eAttPE43711ChipMux pe43711Mux: ѡ��pe43711оƬ
*	�� �� ֵ: ��
******************************************************************************************************/
static void pe43711_gpio_spi_begin(eAttPE43711ChipMux pe43711Mux)
{
	PERI_DX_PIN_OUTPUT_MODE(PE43711_SPI_SCLK);
	PERI_DX_PIN_OUTPUT_MODE(PE43711_SPI_SI);
    //
    PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_SCLK);

    switch (pe43711Mux)
	{
		case ATT_PE43711_IC0:
		{
			PERI_DX_PIN_OUTPUT_MODE(PE43711_SPI_LEA);
			PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEA);
		}
		break;
		case ATT_PE43711_IC1:
		{
			PERI_DX_PIN_OUTPUT_MODE(PE43711_SPI_LEB);
			PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEB);
		}
		break;
		default:
			break;
	}
}

/*****************************************************************************************************
*	�� �� ��: static void pe43711_gpio_spi_end(eAttPE43711ChipMux pe43711Mux)
*	����˵��: ģ��SPI������󣬽�����ΪӲ��SPIģʽ
*	��	  ��:
*			  eAttPE43711ChipMux pe43711Mux: ѡ��pe43711оƬ
*	�� �� ֵ: ��
******************************************************************************************************/
static void pe43711_gpio_spi_end(eAttPE43711ChipMux pe43711Mux)
{
	PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_SCLK);
    PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_SI);
    switch (pe43711Mux)
	{
		case ATT_PE43711_IC0:
		{
			//PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEA);
			PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_LEA);
		}
		break;
		case ATT_PE43711_IC1:
		{
			//PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEB);
			PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_LEB);
		}
		break;
		default:
			break;
	}
}

/*****************************************************************************************************
*	�� �� ��: static void att_pe43711_cs_level_mux(eAttPE43711ChipMux pe43711Mux, AttPE43711CsLevelMux pe43711CsLevelMux)
*	����˵��: ѡ��pe43711оƬ
*	��	  ��:
*			  eAttPE43711ChipMux pe43711Mux: ѡ��pe43711оƬ
*			  AttPE43711CsLevelMux pe43711CsLevelMux: ѡ��PE43711оƬѡ�ߵ�
*	�� �� ֵ: ��
******************************************************************************************************/
static void att_pe43711_cs_level_mux(eAttPE43711ChipMux pe43711Mux, AttPE43711CsLevelMux pe43711CsLevelMux)
{
	if (ATT_PE43711_CS_LOW == pe43711CsLevelMux)
	{
		switch (pe43711Mux)
		{
			case ATT_PE43711_IC0:
			{
				PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_LEA);
			}
			break;
			case ATT_PE43711_IC1:
			{
				PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_LEB);
			}
			break;
			default:
				break;
		}
	}
	else
	{
		switch (pe43711Mux)
		{
			case ATT_PE43711_IC0:
			{
				PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEA);
			}
			break;
			case ATT_PE43711_IC1:
			{
				PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_LEB);
			}
			break;
			default:
				break;
		}
	}
}

/*****************************************************************************************************
*	�� �� ��: static void att_pe43711_gpio_spi_write_reg(eAttPE43711ChipMux pe43711Mux, u8 val)
*	����˵��: pe43711Muxģ��spi����д����
*	��	  ��:
*			  eAttPE43711ChipMux pe43711Mux: ѡ��pe43711MuxоƬ
*             u8 val: д����
*	�� �� ֵ: ��
******************************************************************************************************/
static void att_pe43711_gpio_spi_write_reg(eAttPE43711ChipMux pe43711Mux, u8 val)
{
    u8 wcnt;
    u32 dly_time = 1;
    //��������D[7]��������Ϊ0
    u8 wdata = 0x7F & val;

    pe43711_gpio_spi_begin(pe43711Mux);

    att_pe43711_cs_level_mux(pe43711Mux, ATT_PE43711_CS_LOW);
    att_dx_dly_us(dly_time);

    for (wcnt = 0; wcnt < 8; wcnt++)
    {
    	PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_SCLK);

        if (wdata & 0x1)
        {
        	PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_SI);
        }
        else
        {
        	PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_SI);
        }
        wdata >>= 1;

        att_dx_dly_us(dly_time);
        PERI_DX_PIN_OUPUT_HIGH(PE43711_SPI_SCLK);
    }
    //
    PERI_DX_PIN_OUPUT_LOW(PE43711_SPI_SCLK);
    att_dx_dly_us(10);
    att_pe43711_cs_level_mux(pe43711Mux, ATT_PE43711_CS_HIGH);
    att_dx_dly_us(10);
    att_pe43711_cs_level_mux(pe43711Mux, ATT_PE43711_CS_LOW);
    pe43711_gpio_spi_end(pe43711Mux);
}

/*****************************************************************************************************
*	�� �� ��: static void pe43711_ic0_write(u8 val)
*	����˵��: pe43711 IC0д����
*	��	  ��:
*             val д������
*	�� �� ֵ: ��
******************************************************************************************************/
void pe43711_ic0_write(u8 val)
{
    att_pe43711_gpio_spi_write_reg(ATT_PE43711_IC0, val);
}

/*****************************************************************************************************
*	�� �� ��: int dx_hw_pe43711_ic0_init(void)
*	����˵��: pe43711 IC0��ʼ��
*	��	  ��: ��
*	�� �� ֵ: �ɹ�����:DX_EOK	ʧ�ܷ���:-DX_EIO
******************************************************************************************************/
int dx_hw_pe43711_ic0_init(void)
{
	//SystemSetupSoftIntr(&IntcInstancePtr, INTC_SOFT_INTERRUPT_ID, pe43711_handler);
	float val = 0.0;
	if ((HW_KGR_B3_VER_4_54 == g_HwModuleVer) | (HW_KGR_B3_VER_7_KD == g_HwModuleVer) | (HW_KGR_B3_VER_4_KD == g_HwModuleVer))//B3 ͨ��˥����Ĭ�ϣ���һ��˥��7dB
	{
		val = 0 / 0.25;
	}
	else if (HW_KGR_B1_VER_4_54 == g_HwModuleVer)//B1 ͨ��˥����Ĭ�ϣ���һ��˥��7dB
	{
		val = 0 / 0.25;
	}
	else if (HW_KGR_S_VER_4_54 == g_HwModuleVer)//SƵ��˥����Ĭ�ϣ���һ��˥��3dB
	{
		val = 0 / 0.25;
	}
	else
	{
		return DX_ERROR;
	}
	pe43711_ic0_write(val);
    return DX_EOK;
}

/*****************************************************************************************************
*	�� �� ��: static void pe43711_ic1_write(u8 val)
*	����˵��: pe43711 IC1д����
*	��	  ��:
*             val д������
*	�� �� ֵ: ��
******************************************************************************************************/
void pe43711_ic1_write(u8 val)
{
    att_pe43711_gpio_spi_write_reg(ATT_PE43711_IC1, val);
}

/*****************************************************************************************************
*	�� �� ��: int dx_hw_pe43711_ic1_init(void)
*	����˵��: pe43711 IC1 ��ʼ��
*	��	  ��: ��
*	�� �� ֵ: �ɹ�����:DX_EOK	ʧ�ܷ���:-DX_EIO
******************************************************************************************************/
int dx_hw_pe43711_ic1_init(void)
{
	float val = 0.0;
	if ((HW_KGR_B3_VER_4_54 == g_HwModuleVer) | (HW_KGR_B3_VER_7_KD == g_HwModuleVer) | (HW_KGR_B3_VER_4_KD == g_HwModuleVer))//B3 ͨ��˥����Ĭ�ϣ��ڶ���˥��10dB
	{
		val = 0 / 0.25;
	}
	else if (HW_KGR_B1_VER_4_54 == g_HwModuleVer)//B1 ͨ��˥����Ĭ�ϣ��ڶ���˥��10dB
	{
		val = 0 / 0.25;
	}
	else if (HW_KGR_S_VER_4_54 == g_HwModuleVer)//SƵ��˥����Ĭ�ϣ��ڶ���˥��2dB
	{
		val = 0 / 0.25;
	}
	else
	{
		return DX_ERROR;
	}
	pe43711_ic1_write(val);
    return DX_EOK;
}

/************************ (C) COPYRIGHT Microelectronics *****END OF FILE****/

