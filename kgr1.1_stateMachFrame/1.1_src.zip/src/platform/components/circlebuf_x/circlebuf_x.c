#include "circlebuf_x.h"
//#include <dxdbg.h>

void initializeBuffer(CircularBuffer *cBuffer, char *pbuf, int size) {

    //err_t result;
    cBuffer->buffer = pbuf;
    cBuffer->size = size;
    cBuffer->head = 0;
    cBuffer->tail = 0;
#ifdef USE_OS
    // cBuffer->readMutex = xSemaphoreCreateMutex();
    // cBuffer->writeMutex = xSemaphoreCreateMutex();
    cBuffer->readMutex = dx_lock_create("circlebuf_readMutex", DX_NULL, &result);
    cBuffer->writeMutex = dx_lock_create("circlebuf_writeMutex", DX_NULL, &result);
#endif
}

int writeBufferMutex(CircularBuffer *cBuffer, char data) {
#ifdef USE_OS
    // if (xSemaphoreTake(cBuffer->writeMutex, portMAX_DELAY) != pdTRUE) {
    //     // �޷���ȡд��������д��ʧ��
    //     return 0;
    // }
    err_t result;
    dx_lock_acquire(cBuffer->writeMutex, DX_OPT_PEND_BLOCKING, CONFIG_TIMEOUT_INFINITE, &result);
    if (result != DX_EOK) {
            LOG_I("Warn: write Mutex cant get!!![%s]\r\n", __FUNCTION__);
            return result;
    }
#endif

    if ((cBuffer->tail + 1) % cBuffer->size == cBuffer->head) {
        // ����������
#ifdef USE_OS
        // xSemaphoreGive(cBuffer->writeMutex);
        dx_lock_release(cBuffer->writeMutex, &result);
#endif
        return 0;
    } else {
        cBuffer->buffer[cBuffer->tail] = data;
        cBuffer->tail = (cBuffer->tail + 1) % cBuffer->size;

#ifdef USE_OS
        // xSemaphoreGive(cBuffer->writeMutex);
        dx_lock_release(cBuffer->writeMutex, &result);
#endif

        return 1; // д��ɹ�
    }
}

int writeBufferFromISR(CircularBuffer *cBuffer, char data) {
#if 0
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    int writeSuccess = 0;

    if (xSemaphoreTakeFromISR(cBuffer->writeMutex, &xHigherPriorityTaskWoken) == pdTRUE) {
        if ((cBuffer->tail + 1) % cBuffer->size != cBuffer->head) {
            cBuffer->buffer[cBuffer->tail] = data;
            cBuffer->tail = (cBuffer->tail + 1) % cBuffer->size;
            writeSuccess = 1; // д��ɹ�
        }

        xSemaphoreGiveFromISR(cBuffer->writeMutex, &xHigherPriorityTaskWoken);
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    return writeSuccess;
#endif
    //? �ж����ͷ���������������
    return 0;
}

/**
 * д�������ݵ�ѭ�������������������汾��
 * @param cBuffer ѭ���������ṹָ��
 * @param data Ҫд�������ָ��
 * @param length Ҫд������ݳ���
 * @return �ɹ�д���������������д��ʧ���򷵻� 0
 */
int writeBufferMultipleMutex(CircularBuffer *cBuffer, char *data, int length) {
#ifdef USE_OS
    // ���Ի�ȡд������
    // if (xSemaphoreTake(cBuffer->writeMutex, portMAX_DELAY) != pdTRUE) {
    //     // �޷���ȡд��������д��ʧ��
    //     return 0;
    // }
    err_t result;
    dx_lock_acquire(cBuffer->writeMutex, DX_OPT_PEND_BLOCKING, CONFIG_TIMEOUT_INFINITE, &result);
    if (result != DX_EOK) {
            LOG_I("Warn: write Mutex cant get!!![%s]\r\n", __FUNCTION__);
            return result;
    }
#endif

    int successCount = 0;
    // ��ȡ��д����
    int capacity = getWritableCapacityNoMutex(cBuffer);

    // �����д����С�ڴ�д�����ݳ��ȣ�ֱ�ӷ���д��ʧ��
    if (capacity < length) {
#ifdef USE_OS
    // �ͷ�д������
    // xSemaphoreGive(cBuffer->writeMutex);
    dx_lock_release(cBuffer->writeMutex, &result);
#endif
        return 0;
    }

    // ѭ��д�����ݵ�������
    while (successCount < length) {
        cBuffer->buffer[cBuffer->tail] = data[successCount];
        cBuffer->tail = (cBuffer->tail + 1) % cBuffer->size;
        successCount++;
    }

#ifdef USE_OS
    // �ͷ�д������
    // xSemaphoreGive(cBuffer->writeMutex);
    dx_lock_release(cBuffer->writeMutex, &result);
#endif

    return successCount; // ���سɹ�д�����������
}


int readBufferMutex(CircularBuffer *cBuffer, char *data) {
#ifdef USE_OS
    // if (xSemaphoreTake(cBuffer->readMutex, portMAX_DELAY) != pdTRUE) {
    //     // �޷���ȡ������������ȡʧ��
    //     return 0;
    // }
    err_t result;
    dx_lock_acquire(cBuffer->readMutex, DX_OPT_PEND_BLOCKING, CONFIG_TIMEOUT_INFINITE, &result);
    if (result != DX_EOK) {
            LOG_I("Warn: write Mutex cant get!!![%s]\r\n", __FUNCTION__);
            return result;
    }
#endif

    if (cBuffer->head == cBuffer->tail) {
        // ������Ϊ��
#ifdef USE_OS
        // xSemaphoreGive(cBuffer->readMutex);
        dx_lock_release(cBuffer->readMutex, &result);
#endif
        return 0;
    } else {
        *data = cBuffer->buffer[cBuffer->head];
        cBuffer->head = (cBuffer->head + 1) % cBuffer->size;

#ifdef USE_OS
        // xSemaphoreGive(cBuffer->readMutex);
        dx_lock_release(cBuffer->readMutex, &result);
#endif

        return 1; // ��ȡ�ɹ�
    }
}

int readBufferMultipleMutex(CircularBuffer *cBuffer, char *data, int length) {
#ifdef USE_OS
    // if (xSemaphoreTake(cBuffer->readMutex, portMAX_DELAY) != pdTRUE) {
    //     // �޷���ȡ������������ȡʧ��
    //     return 0;
    // }
    err_t result;
    dx_lock_acquire(cBuffer->readMutex, DX_OPT_PEND_BLOCKING, CONFIG_TIMEOUT_INFINITE, &result);
    if (result != DX_EOK) {
            LOG_I("Warn: read Mutex cant get!!![%s]\r\n", __FUNCTION__);
            return result;
    }
#endif

    int successCount = 0;

    for (int i = 0; i < length; ++i) {
        if (cBuffer->head == cBuffer->tail) {
            // ������Ϊ��
            break; // ��ȡʧ�ܣ�����ѭ��
        } else {
            data[i] = cBuffer->buffer[cBuffer->head];
            cBuffer->head = (cBuffer->head + 1) % cBuffer->size;
            successCount++;
        }
    }

#ifdef USE_OS
    // xSemaphoreGive(cBuffer->readMutex);
    dx_lock_release(cBuffer->readMutex, &result);
#endif

    return successCount;
}

// �����ǲ�ʹ�û������Ķ�д�ӿ�

int writeBufferNoMutex(CircularBuffer *cBuffer, char data) {
    if ((cBuffer->tail + 1) % cBuffer->size == cBuffer->head) {
        // ����������
        return 0;
    } else {
        cBuffer->buffer[cBuffer->tail] = data;
        cBuffer->tail = (cBuffer->tail + 1) % cBuffer->size;
        return 1; // д��ɹ�
    }
}

int readBufferNoMutex(CircularBuffer *cBuffer, char *data) {
    if (cBuffer->head == cBuffer->tail) {
        // ������Ϊ��
        return 0;
    } else {
        *data = cBuffer->buffer[cBuffer->head];
        cBuffer->head = (cBuffer->head + 1) % cBuffer->size;
        return 1; // ��ȡ�ɹ�
    }
}

int readBufferMultipleNoMutex(CircularBuffer *cBuffer, char *data, int length) {
    int successCount = 0;

    for (int i = 0; i < length; ++i) {
        if (cBuffer->head == cBuffer->tail) {
            // ������Ϊ��
            break; // ��ȡʧ�ܣ�����ѭ��
        } else {
            data[i] = cBuffer->buffer[cBuffer->head];
            cBuffer->head = (cBuffer->head + 1) % cBuffer->size;
            successCount++;
        }
    }

    return successCount;
}

int writeBufferMultipleNoMutex(CircularBuffer *cBuffer, char *data, int length) {
    int successCount = 0;

    for (int i = 0; i < length; ++i) {
        if ((cBuffer->tail + 1) % cBuffer->size == cBuffer->head) {
            // ����������
            break; // д��ʧ�ܣ�����ѭ��
        } else {
            cBuffer->buffer[cBuffer->tail] = data[i];
            cBuffer->tail = (cBuffer->tail + 1) % cBuffer->size;
            successCount++;
        }
    }

    return successCount;
}

int readBufferMultipleAndClearNoMutex(CircularBuffer *cBuffer, char *data, int length) {
    int successCount = 0;

    for (int i = 0; i < length; ++i) {
        if (cBuffer->head == cBuffer->tail) {
            // ������Ϊ��
            break; // ��ȡʧ�ܣ�����ѭ��
        } else {
            data[i] = cBuffer->buffer[cBuffer->head];
            cBuffer->head = (cBuffer->head + 1) % cBuffer->size;
            successCount++;
        }
    }

    // ��ջ�����
    cBuffer->head = cBuffer->tail;

    return successCount;
}

int getRemainingCountNoMutex(CircularBuffer *cBuffer) {
    int count;

    count = cBuffer->tail - cBuffer->head;
    if(count < 0)
    {
        count += cBuffer->size;
    }

    return count;
}

int getWritableCapacityNoMutex(CircularBuffer *cBuffer) {
    int capacity;
    //? ����head �仯����Ҫ��������
    if (cBuffer->head <= cBuffer->tail) {
        capacity = cBuffer->size - (cBuffer->tail - cBuffer->head) - 1;
    } else {
        capacity = cBuffer->head - cBuffer->tail - 1;
    }

    return capacity;
}

void clearBufferNoMutex(CircularBuffer *cBuffer) {
    cBuffer->head = cBuffer->tail;
}
