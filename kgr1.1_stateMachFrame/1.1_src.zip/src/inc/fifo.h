#ifndef ZS_FIFO_H_DADFASFDASDF
#define ZS_FIFO_H_DADFASFDASDF

#include "dxdef.h"

BOOL dequeue(char * enVal);

BOOL enqueue(unsigned char enVal);

unsigned char initQueue(unsigned char capVal);

BOOL isEmpty();

BOOL isFull();

#endif
