#ifndef __ZSVERSION_H__
#define __ZSVERSION_H__


#ifdef __cplusplus
extern "C" {
#endif

#define APP_VERSION "AntiInterferenceCircuit-V1.06.01"

	
#define APP_VERSION_ALL APP_VERSION"-202508201051"

	
#ifdef __cplusplus
}
#endif

#endif 

